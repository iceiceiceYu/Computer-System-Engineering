package main.ifs;

public interface Id {
    // empty interface
}
